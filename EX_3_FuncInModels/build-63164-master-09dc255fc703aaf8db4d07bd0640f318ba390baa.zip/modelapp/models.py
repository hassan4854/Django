from django.db import models


class User(models.Model):

    def change_name(self, new_name):
        pass

    def change_password(self, new_password):
        pass

    def change_score(self, x):
        pass

    def __str__(self):
        return self.name
